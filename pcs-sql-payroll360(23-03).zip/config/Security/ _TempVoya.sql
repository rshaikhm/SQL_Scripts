﻿CREATE SCHEMA [ #TempVoya]
    AUTHORIZATION [dbo];

