﻿  
/*----------------------------------------------------------------------------  
Created By: Fanisha verma  
Created Date: 30th Dec 2020  
Purpose: To insert record in tbl_Payload_Received when a file is received in Azure Blob Storage   
------------------------------------------------------------------------------*/  
  
--Exec SP_InsertIntoFileReceived @IngestionType, @EmailId, @PayloadName, @FileType, @UserName,@StorageLink, @SourceProviderName, @Result 
--Exec SP_InsertIntoFileReceived '3','shelara@pcscapital.com','Omni.txt','6','shelara@pcscapital.com','/tsm','10'  
--Exec SP_InsertIntoFileReceived '1','shelara@pcscapital.com','voya123.csv','11','shelara@pcscapital.com','/tsm','pcs'  
--Exec SP_InsertIntoFileReceived '4','vermaf@pcscapital.com','PAYLOCITY.xlsx','6','verma fanisha','/tsm','10'  

--Exec SP_InsertIntoFileReceived null,'null','omni_05012021_demo12.txt',0,'null','tsm/omni','null',0
--Exec SP_InsertIntoFileReceived null,'null','omni_05012021_demo12.csv',0,'null','tsm/omni','null',0
--Exec SP_InsertIntoFileReceived null,'null','omni_05012021_demo9.txt',0,'null','tsm/SchoolsFirst','null',0

--Exec SP_InsertIntoFileReceived null,'null','voya_05012021_demo11.csv',0,'null','tsm/voya','null',0
--Exec SP_InsertIntoFileReceived null,'null','voya_05012021_demo11.txt',0,'null','tsm/voya','null',0
--Exec SP_InsertIntoFileReceived null,'null','voya_05012021_demo12.csv',0,'null','tsm/SchoolsFirst','null',0
--Exec SP_InsertIntoFileReceived null,'null','voya_05012021_demo13.csv',0,'null','tsm/paylocity','null',0

--Exec SP_InsertIntoFileReceived null,'null','schoolsfirst_20210108_34567.xls',0,'null','tsm/schoolsfirst','null',0 
--Exec SP_InsertIntoFileReceived null,'null','schoolsfirst_20210108_34567.txt',0,'null','tsm/schoolsfirst','null',0 
--Exec SP_InsertIntoFileReceived null,'null','schoolsfirst_20210108_34567.txt',0,'null','tsm/paylocity','null',0 

--Exec SP_InsertIntoFileReceived null,'null','Omni_11012021_39344569866.TXT',0,'null','tsm/omni','null',0
--Exec SP_InsertIntoFileReceived null,'null','Omni_11012021_39342269866.TXT',0,'null','tsm/omni','null',0
--Exec SP_InsertIntoFileReceived null,'null','Omni_11012021_39342999870.TXT',0,'null','tsm/omni','null',0

--Exec SP_InsertIntoFileReceived null,'null','VOYA_18102020_$27292.0896.csv',0,'null','tsm/voya','null','null',0,0,0,',', 'NA',  'NA',  'NA',  'NA',  'NA', 0
--Exec SP_InsertIntoFileReceived null,'null','VOYA_18102020_$27292_08197.csv',0,'null','tsm/voya','null','null',0,0,0,',', 'NA',  'NA',  'NA',  'NA',  'NA', 0
--Exec SP_InsertIntoFileReceived null,'null','OMNI_1812020New.csv',0,'null','relius','null','null',0,0,0,',', 'NA',  'NA',  'NA',  'NA',  'NA', 0
--Exec SP_InsertIntoFileReceived null,'null','voya_1812020New1.csv',0,'null','relius','null','null',0,0,0,',', 'NA',  'NA',  'NA',  'NA',  'NA', 0

--Exec SP_InsertStatusIntoFileReceived 'kratikhandelwal3190@gmail.com','45310_Payroll_BCHA1645_12242020_510.csv'

CREATE PROCEDURE [dbo].[SP_InsertIntoFileReceived]  
@IngestionType INT,  
@EmailId VARCHAR(200) = NULL,  
@PayloadName VARCHAR(250),
@FileType INT = 0,  
@UserName VARCHAR(50) = NULL,  
@StorageLink VARCHAR(1000) = NULL,  --'tsm/omni'
@SourceProviderName VARCHAR(150) = NULL,  
@ActualFile  VARCHAR(1000) = NULL,
@Result INT = 0 OUTPUT, --1 = INSERT SUCCESS/ 0 = ERROR or FILE EXIST 
@PayloadReceivedId INT = 0 OUTPUT,
@InboundSourceSetupId INT = 0 OUTPUT,
@Delimiter VARCHAR(50) = NULL OUTPUT,  
@IsColumnHeaderAvailable VARCHAR(50) = NULL OUTPUT,
@FileNameExtension VARCHAR(50) = NULL OUTPUT,
@ContainerName VARCHAR(100) = NULL OUTPUT,
@FolderName VARCHAR(100) = NULL OUTPUT,
@SheetName VARCHAR(100) = NULL OUTPUT,
@DataHeaderRow INT = 0 OUTPUT
  
AS BEGIN  
SET NOCOUNT ON  
 
DECLARE @Inbound_Source_SetupID INT  
DECLARE @FileExitsCount INT  
DECLARE @FileExitsInprogressCount INT 
DECLARE @FileNamePatternSubstring VARCHAR(50)  
DECLARE @FileNameExtentionSubstring VARCHAR(50)
DECLARE @StorageLinkSubstring VARCHAR(50)
DECLARE @FileTypeExists_LookupID INT  
DECLARE @Sort_Order INT
DECLARE @Filename_Structure_Parts INT
DECLARE @Payload_Received_ID INT
DECLARE @FromEmailId VARCHAR(150)

SET @Result = 0  
SET @PayloadReceivedId = 0
SET @InboundSourceSetupId = 0
SET @Inbound_Source_SetupID = 0
SET @Delimiter = 'NA' 
SET @IsColumnHeaderAvailable = 'N'
SET @FileTypeExists_LookupID = 0
SET @FileNameExtension = ''
SET @ContainerName = ''
SET @FolderName = ''
SET @SheetName = ''
SET @DataHeaderRow = 0
SET @FileExitsInprogressCount = 0
SET @FromEmailId = ''
  
---If PayloadName is already present in tbl_Payload_Received then No changes else Insert in the table  
SET @FileExitsCount = (SELECT COUNT(*) FROM dbo.tbl_Payload_Received NOLOCK WHERE UPPER(Payload_Name) = UPPER(@PayloadName))  
PRINT '@FileExitsCount: '
PRINT  @FileExitsCount  

SET @FileExitsInprogressCount = (SELECT COUNT(*) FROM dbo.tbl_Payload_Received NOLOCK WHERE UPPER(Payload_Name) = UPPER(@PayloadName) AND UPPER(Status) = 'INPROGRESS') 
PRINT '@FileExitsInprogressCount: ' 
PRINT @FileExitsInprogressCount 
  
IF(@FileExitsCount = 0 OR @FileExitsInprogressCount > 0)  
BEGIN  
  
  SET @FileNamePatternSubstring=(SELECT UPPER(SUBSTRING(@PayloadName, 0, CHARINDEX('_',@PayloadName))))  
  SET @FileNameExtentionSubstring = (SELECT UPPER(REVERSE(LEFT(REVERSE(@PayloadName), CHARINDEX('.', REVERSE(@PayloadName)) - 1)))) 

   IF (CHARINDEX( '/', @StorageLink) > 0)
	BEGIN
	 SET @StorageLinkSubstring  = (SELECT UPPER(REVERSE(LEFT(REVERSE(TRIM('/' FROM @StorageLink)), CHARINDEX('/', REVERSE(TRIM('/' FROM @StorageLink))) - 1)))) ----tsm/omni
	 SET @FolderName  =  LOWER(TRIM('/' FROM @StorageLinkSubstring)) ---omni
     SET @ContainerName = TRIM('/' FROM  REPLACE(LOWER(TRIM('/' FROM @StorageLink)), @FolderName, '')) ----tsm
	 PRINT '@StorageLink contains /'
    END
	ELSE
	BEGIN
	 SET @StorageLinkSubstring  = @StorageLink
     SET @ContainerName = LOWER(TRIM('/' FROM @StorageLinkSubstring))
	 PRINT '@StorageLink doesnot contains /'
	END

   PRINT '@ContainerName: ' + @ContainerName
   PRINT '@FolderName: ' + @FolderName
  
  IF(@FileNamePatternSubstring='')    
  BEGIN  
   PRINT 'null @FileNamePatternSubstring encounter'  
   SET @FileNamePatternSubstring=(SELECT UPPER(SUBSTRING(@PayloadName, 0, CHARINDEX('.',@PayloadName))))  
  END  

  PRINT '@FileNamePatternSubstring: ' + @FileNamePatternSubstring

  IF(@StorageLinkSubstring='')  
  BEGIN  
   PRINT 'null @StorageLinkSubstring encounter'  
   SET @StorageLinkSubstring=(SELECT CHARINDEX(@FileNamePatternSubstring, UPPER(@StorageLinkSubstring)))
  END 

  PRINT '@StorageLinkSubstring: ' + @StorageLinkSubstring

  IF(@FileNameExtentionSubstring='')    
  BEGIN  
   PRINT 'null @FileNameExtentionSubstring encounter'  
   SET @FileNameExtension=''; 
  END  
  ELSE
  BEGIN
    PRINT 'Not null  @FileNameExtentionSubstring encounter'  
	IF(UPPER(SUBSTRING(@FileNameExtentionSubstring,1,3)) = 'XLS')
	 BEGIN
	 SET @FileNameExtension = 'excel'; 
	 END
	ELSE
	BEGIN
	SET @FileNameExtension = LOWER(@FileNameExtentionSubstring)
	END
  END

  PRINT '@FileNameExtentionSubstring: '
  PRINT @FileNameExtentionSubstring

  PRINT '@FileNameExtension: ' + @FileNameExtension
  
  PRINT '@PayloadName: '
  PRINT @PayloadName
      
  PRINT 'begin1'  
  
  SET @FileTypeExists_LookupID = (  
  SELECT TOP 1 L.Lookup_ID FROM [dbo].[tbl_Lookup] L  
  WHERE SUBSTRING(UPPER(L.Short_Name),1,3) = UPPER(SUBSTRING(@FileNameExtentionSubstring,1,3)) 
  AND L.IsActive= '1')
  
  PRINT 'end1' 

  PRINT '@FileTypeExists_LookupID: '   
  PRINT @FileTypeExists_LookupID
  
 IF(@FileTypeExists_LookupID > 0)
 BEGIN

  PRINT ' IF(@FileTypeExists_LookupID > 0) BEGINS'  
  
 IF(@FileExitsInprogressCount = 0)
 BEGIN

  SELECT @Inbound_Source_SetupID = I.Inbound_Source_SetupID, 
  @Filename_Structure_Parts = I.Filename_Structure_Parts,
  @Delimiter = I.Delimiter,
  @IsColumnHeaderAvailable = I.Is_Column_Header_Available,
  @SheetName = I.Sheet_Name,
  @DataHeaderRow = I.Data_Header_Row,
  @FromEmailId = I.From_Email_ID
  FROM [dbo].[tbl_Inbound_Source_Setup] I 
  WHERE UPPER(@PayloadName) LIKE '%' + UPPER(TRIM('*' FROM I.File_Name_Pattern)) + '%'
  AND UPPER(TRIM('/' FROM I.Storage_Folder_Name)) LIKE UPPER(TRIM('/' FROM @StorageLink )) -- LIKE @StorageLinkSubstring
  AND I.Is_Active = 1
 -- AND I.Type_Of_Ingestion_LK_ID = @IngestionType
  -- AND I.File_TypE_LK_ID = @FileTypeExists_LookupID
  -- AND UPPER(TRIM('*' FROM I.File_Name_Pattern)) LIKE @FileNamePatternSubstring
  END
  ELSE
  BEGIN

   SELECT @Inbound_Source_SetupID = I.Inbound_Source_SetupID, 
  @Filename_Structure_Parts = I.Filename_Structure_Parts,
  @Delimiter = I.Delimiter,
  @IsColumnHeaderAvailable = I.Is_Column_Header_Available,
  @SheetName = I.Sheet_Name,
  @DataHeaderRow = I.Data_Header_Row,
  @FromEmailId = I.From_Email_ID
  FROM [dbo].[tbl_Inbound_Source_Setup] I 
  WHERE UPPER(@PayloadName) LIKE '%' + UPPER(TRIM('*' FROM I.File_Name_Pattern)) + '%'
  AND UPPER(TRIM('/' FROM I.Storage_Folder_Name)) LIKE UPPER(TRIM('/' FROM @StorageLink )) -- LIKE @StorageLinkSubstring
  AND I.Is_Active = 1
  END

  IF(@FileNameExtension != '' AND @FileNameExtension = 'excel')
  BEGIN
   SET @Delimiter = 'NA'
  END

  IF(@FileNameExtension != '' AND @FileNameExtension = 'csv')
  BEGIN
    SET @Delimiter = ','
  END
	
  PRINT 'end2'  

  PRINT '@Inbound_Source_SetupID'
  PRINT  @Inbound_Source_SetupID
  
  PRINT '@FileTypeExists_LookupID'   
  PRINT  @FileTypeExists_LookupID 
  
  PRINT '@Filename_Structure_Parts'   
  PRINT  @Filename_Structure_Parts 

  IF(@Inbound_Source_SetupID > 0)  
  BEGIN  
  
  SET @InboundSourceSetupId = @Inbound_Source_SetupID

  PRINT 'IF BEGIN---'
	
 IF(@FileExitsInprogressCount = 0)
 BEGIN 

  PRINT 'Insert into tbl_Payload_Received'

  INSERT INTO dbo.tbl_Payload_Received(  
        [Payload_Name]  
         ,[Received_Date_And_Time]  
         ,[Inbound_Source_Setup_ID]  
         ,[Loaded_By] -- the person who provided source @SourceProviderName  
         ,[File_Type_LK_ID] -- @FileType -- Values: Excel, Delimiter etc.  
         ,[As_OF_Date]  
         ,[Actual_File] -- @StorageLink-link of azure storage blob  
         ,[Status] -- Values -received/processed/error  
         ,[Created_By] -- @UserName param  
         ,[Created_Date]  
         ,[Updated_By]  
         ,[Updated_Date])  
        Values(@PayloadName,CURRENT_TIMESTAMP,@Inbound_Source_SetupID,'SYSTEM',@FileTypeExists_LookupID,  
         GETDATE(),@StorageLink,'RECEIVED', 'SYSTEM', GETDATE(),'SYSTEM', GETDATE())  

		SET @Payload_Received_ID = (SELECT F.Payload_Received_ID  FROM dbo. tbl_Payload_Received F WHERE F.Payload_Name = @PayloadName )

		SET @PayloadReceivedId = @Payload_Received_ID

		PRINT '@Payload_Received_ID'
		PRINT @Payload_Received_ID

	    ---Code to enter header received starts
		PRINT 'Code to enter header received starts' 

		IF(@Filename_Structure_Parts IS NOT NULL AND @Filename_Structure_Parts > 0)
		BEGIN
			  PRINT 'IF @Filename_Structure_Parts STARTS---'
	 
			  EXEC [dbo].[SP_InsertIntoHeaderReceived]  @Inbound_Source_SetupID, @Filename_Structure_Parts, @FileNameExtentionSubstring, @PayloadName, @PayloadReceivedId

			  PRINT 'IF @Filename_Structure_Parts ENDS---'
		END   
		PRINT 'Code to enter header received ends' 
		 ---Code to enter header received ends

		SET @Result=1 
		SELECT @Result AS Result, @PayloadReceivedId AS PayloadReceivedId, @InboundSourceSetupId AS InboundSourceSetupID, @Delimiter AS Delimiter, @IsColumnHeaderAvailable AS IsColumnHeaderAvailable, @FileNameExtension AS FileExtension, @SheetName AS SheetName, @ContainerName AS ContainerName, @FolderName AS FolderName, @DataHeaderRow AS DataHeaderRow


END
ELSE
BEGIN
  
 PRINT 'Update tbl_Payload_Received starts'

		SET @Payload_Received_ID = (SELECT F.Payload_Received_ID  FROM dbo. tbl_Payload_Received F WHERE F.Payload_Name=@PayloadName )
		SET @PayloadReceivedId = @Payload_Received_ID

		 PRINT '@Payload_Received_ID'
		 PRINT @Payload_Received_ID

		 DECLARE @FromEmailIDFileReceived VARCHAR(100) 
		 SET @FromEmailIDFileReceived =''
		 SET @FromEmailIDFileReceived = (SELECT F.From_Email_ID  FROM dbo. tbl_Payload_Received F WHERE F.Payload_Name=@PayloadName )

		 IF(@FromEmailIDFileReceived = @FromEmailId)
		 BEGIN
		 UPDATE dbo. tbl_Payload_Received
		 SET Status = 'RECEIVED',
		 File_Type_LK_ID = @FileTypeExists_LookupID,
		 Actual_File = @StorageLink
		 WHERE Payload_Received_ID = @Payload_Received_ID

		 PRINT 'Update tbl_Payload_Received status Received ends'

		---Code to enter header received starts
		PRINT 'Code to enter header received starts' 

		IF(@Filename_Structure_Parts IS NOT NULL AND @Filename_Structure_Parts > 0)
		BEGIN
			  PRINT 'IF @Filename_Structure_Parts STARTS---'
	 
			  EXEC [dbo].[SP_InsertIntoHeaderReceived]  @Inbound_Source_SetupID, @Filename_Structure_Parts, @FileNameExtentionSubstring, @PayloadName, @PayloadReceivedId

			  PRINT 'IF @Filename_Structure_Parts ENDS---'
		END   

		PRINT 'Code to enter header received ends' 
		 ---Code to enter header received ends

		SET @Result=1 
		SELECT @Result AS Result, @PayloadReceivedId AS PayloadReceivedId, @InboundSourceSetupId AS InboundSourceSetupID, @Delimiter AS Delimiter, @IsColumnHeaderAvailable AS IsColumnHeaderAvailable, @FileNameExtension AS FileExtension, @SheetName AS SheetName, @ContainerName AS ContainerName, @FolderName AS FolderName, @DataHeaderRow AS DataHeaderRow

		END

		 ELSE
		 BEGIN
		 UPDATE dbo. tbl_Payload_Received
		 SET Status = 'ERROR',
		 File_Type_LK_ID = @FileTypeExists_LookupID,
		 Actual_File = @StorageLink
		 WHERE Payload_Received_ID = @Payload_Received_ID

		 PRINT 'Update tbl_Payload_Received status Error ends'

		PRINT 'No insert in tbl_PayloadReceived table as From_Email_Id did not match' 

		SET @Result=0  
		SELECT @Result AS Result, @PayloadReceivedId AS PayloadReceivedId, @InboundSourceSetupId AS InboundSourceSetupID, @Delimiter AS Delimiter, @IsColumnHeaderAvailable AS IsColumnHeaderAvailable, @FileNameExtension AS FileExtension, @SheetName AS SheetName, @ContainerName AS ContainerName, @FolderName AS FolderName, @DataHeaderRow AS DataHeaderRow
		END 
		 		 
END

END
ELSE  
   BEGIN  
     PRINT 'No insert in tbl_PayloadReceived table as InboundSourceSetupID is 0' 

	 IF(@FileExitsInprogressCount > 0)
	 BEGIN

	  PRINT 'Update tbl_Payload_Received starts'

		SET @Payload_Received_ID = (SELECT F.Payload_Received_ID  FROM dbo. tbl_Payload_Received F WHERE F.Payload_Name=@PayloadName )

		SET @PayloadReceivedId = @Payload_Received_ID

		 PRINT '@Payload_Received_ID'
		 PRINT @Payload_Received_ID

		 UPDATE dbo. tbl_Payload_Received
		 SET Status = 'ERROR',
		 File_Type_LK_ID = @FileTypeExists_LookupID,
		 Actual_File = @StorageLink
		 WHERE Payload_Received_ID = @Payload_Received_ID

		 PRINT 'Update tbl_Payload_Received ends'

		 END

	 SET @Result=0 --- No insert as the InboundSourceSetupID is null 
	 SELECT @Result AS Result, @PayloadReceivedId AS PayloadReceivedId, @InboundSourceSetupId AS InboundSourceSetupID, @Delimiter AS Delimiter, @IsColumnHeaderAvailable AS IsColumnHeaderAvailable, @FileNameExtension AS FileExtension, @SheetName AS SheetName, @ContainerName AS ContainerName, @FolderName AS FolderName, @DataHeaderRow AS DataHeaderRow
   END 
END  
  
ELSE  
  BEGIN   
    PRINT 'No insert in tbl_PayloadReceived table as the File type does not exists' 
	SET @Result = 0 --- No insert as the File type does not exists
	SELECT @Result AS Result, @PayloadReceivedId AS PayloadReceivedId, @InboundSourceSetupId AS InboundSourceSetupID, @Delimiter AS Delimiter, @IsColumnHeaderAvailable AS IsColumnHeaderAvailable, @FileNameExtension AS FileExtension, @SheetName AS SheetName, @ContainerName AS ContainerName, @FolderName AS FolderName, @DataHeaderRow AS DataHeaderRow
  END  
  
END

ELSE  
BEGIN
	PRINT 'No insert in tbl_PayloadReceived table as the File name exists with status other than INPROGRESS' 
	SET @Result = 0 ---No insert in tbl_PayloadReceived table as the File name exists with status other than INPROGRESS
	SELECT @Result AS Result, @PayloadReceivedId AS PayloadReceivedId, @InboundSourceSetupId AS InboundSourceSetupID, @Delimiter AS Delimiter, @IsColumnHeaderAvailable AS IsColumnHeaderAvailable, @FileNameExtension AS FileExtension,  @SheetName AS SheetName, @ContainerName AS ContainerName, @FolderName AS FolderName, @DataHeaderRow AS DataHeaderRow
END  

END
