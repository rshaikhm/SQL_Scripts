﻿--EXEC SP_CheckCorrectFolderPathForFileInsert 'tsm/omni', 0

CREATE PROCEDURE [dbo].[SP_CheckCorrectFolderPathForFileInsert]  
@FolderPath VARCHAR(1000) = NULL,  
@Result INT = 0 OUTPUT -- 1 = CORRECT PATH / 0 = INCORRECT PATH 
  
AS BEGIN  
SET NOCOUNT ON  
 
IF( CHARINDEX('ERROR',UPPER(@FolderPath)) > 0  OR  CHARINDEX('ARCHIVE',UPPER(@FolderPath)) > 0  ) 
BEGIN 

--BEGIN TRY 
--RAISERROR ('Error raised in SP_CheckCorrectFolderPathForFileInsert Result 1 Scenario Testing', -- Message text.  
--            16, -- Severity.  
--            1 -- State.  
--            )
--END TRY  
--BEGIN CATCH
--RAISERROR ('Error raised in SP_CheckCorrectFolderPathForFileInsert Result 1 Scenario Testing', -- Message text.  
--            16, -- Severity.  
--            1 -- State.  
--            )
---END CATCH 

SET @Result = 0
  SELECT @Result AS Result  
END  

ELSE
--BEGIN TRY 
--RAISERROR ('Error raised in SP_CheckCorrectFolderPathForFileInsert Result 1 Scenario Testing', -- Message text.  
--            16, -- Severity.  
--            1 -- State.  
--            )
--END TRY  
--BEGIN CATCH
--RAISERROR ('Error raised in SP_CheckCorrectFolderPathForFileInsert Result 1 Scenario Testing', -- Message text.  
--            16, -- Severity.  
--            1 -- State.  
--            )
---END CATCH 

SET @Result = 1
  SELECT @Result AS Result
   
END